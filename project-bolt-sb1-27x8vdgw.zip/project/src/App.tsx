import React, { useState } from 'react';
import {
  Shield,
  Car,
  Radio,
  Lock,
  AlertTriangle,
  Server,
  Network,
  Wifi,
  Key,
  ShieldAlert
} from 'lucide-react';

const SecurityFramework = () => {
  const [activeSection, setActiveSection] = useState('overview');

  const frameworks = [
    {
      id: 'overview',
      title: 'Framework Overview',
      icon: Shield,
      content: 'A comprehensive security approach for autonomous and connected vehicles focusing on multiple layers of protection.',
    },
    {
      id: 'v2v',
      title: 'V2V Communication Security',
      icon: Radio,
      content: 'Secure vehicle-to-vehicle communication protocols using encrypted channels and authenticated messaging systems.',
    },
    {
      id: 'access',
      title: 'Access Control',
      icon: Lock,
      content: 'Multi-factor authentication and role-based access control for vehicle systems and remote operations.',
    },
    {
      id: 'threats',
      title: 'Threat Detection',
      icon: AlertTriangle,
      content: 'Real-time monitoring and anomaly detection systems to identify potential security breaches.',
    },
    {
      id: 'infrastructure',
      title: 'Infrastructure Security',
      icon: Server,
      content: 'Protecting backend systems, cloud infrastructure, and communication networks.',
    }
  ];

  const securityLayers = [
    {
      title: 'Network Security',
      icon: Network,
      description: 'Secured communication channels with end-to-end encryption'
    },
    {
      title: 'Wireless Protection',
      icon: Wifi,
      description: 'Protected wireless interfaces and protocols'
    },
    {
      title: 'Authentication',
      icon: Key,
      description: 'Strong authentication mechanisms for all system access'
    },
    {
      title: 'Threat Monitoring',
      icon: ShieldAlert,
      description: 'Continuous security monitoring and threat detection'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Header */}
      <header className="bg-black/30 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center space-x-4">
            <Car className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Autonomous Vehicle Security Framework</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="mb-12 text-center">
          <h2 className="text-4xl font-bold mb-4">Securing the Future of Mobility</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A comprehensive cybersecurity framework designed to protect autonomous and connected vehicles
            from emerging threats while ensuring safe and reliable operation.
          </p>
        </div>

        {/* Framework Sections */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {frameworks.map((framework) => {
            const IconComponent = framework.icon;
            return (
              <button
                key={framework.id}
                onClick={() => setActiveSection(framework.id)}
                className={`p-6 rounded-xl transition-all duration-300 ${
                  activeSection === framework.id
                    ? 'bg-blue-600 shadow-lg shadow-blue-500/30'
                    : 'bg-gray-800 hover:bg-gray-700'
                }`}
              >
                <IconComponent className="w-8 h-8 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{framework.title}</h3>
                <p className="text-gray-300 text-left">{framework.content}</p>
              </button>
            );
          })}
        </div>

        {/* Security Layers */}
        <div className="bg-gray-800 rounded-xl p-8">
          <h3 className="text-2xl font-bold mb-6">Security Layer Implementation</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {securityLayers.map((layer, index) => {
              const IconComponent = layer.icon;
              return (
                <div key={index} className="bg-gray-700 rounded-lg p-6">
                  <IconComponent className="w-6 h-6 mb-4 text-blue-400" />
                  <h4 className="text-lg font-semibold mb-2">{layer.title}</h4>
                  <p className="text-gray-300 text-sm">{layer.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Visual Representation */}
        <div className="mt-12 bg-[url('https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80')] bg-cover bg-center rounded-xl overflow-hidden">
          <div className="bg-black/60 backdrop-blur-sm p-8">
            <h3 className="text-2xl font-bold mb-6">Comprehensive Protection</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-blue-600/20 backdrop-blur-sm rounded-lg p-6">
                <h4 className="font-semibold mb-2">Prevention</h4>
                <p className="text-sm text-gray-300">Proactive security measures to prevent unauthorized access and attacks</p>
              </div>
              <div className="bg-blue-600/20 backdrop-blur-sm rounded-lg p-6">
                <h4 className="font-semibold mb-2">Detection</h4>
                <p className="text-sm text-gray-300">Advanced systems to identify potential security threats in real-time</p>
              </div>
              <div className="bg-blue-600/20 backdrop-blur-sm rounded-lg p-6">
                <h4 className="font-semibold mb-2">Response</h4>
                <p className="text-sm text-gray-300">Automated incident response and recovery procedures</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-gray-400">
            Autonomous Vehicle Security Framework • Protecting the Future of Transportation
          </p>
        </div>
      </footer>
    </div>
  );
};

export default SecurityFramework;